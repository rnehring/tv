<?php

return [

    /*
    |----------------------------------------------------------------------
    | Data source
    |----------------------------------------------------------------------
    | 'epicor'  – pull live from the Epicor SQL Server (see the 'epicor'
    |             connection in config/database.php and the EPICOR_* env vars).
    | 'sample'  – don't touch the ERP; keep showing the seeded sample snapshot.
    |             Use this until the ERP connection is wired up.
    */
    'source' => env('OTIF_SOURCE', 'sample'),

    // A snapshot older than this is flagged as stale on the slide (still shown).
    'max_age_minutes' => env('OTIF_MAX_AGE_MINUTES', 60),

    // How often the scheduled fetch runs (minutes).
    'refresh_minutes' => env('OTIF_REFRESH_MINUTES', 10),

    /*
    |----------------------------------------------------------------------
    | Business units
    |----------------------------------------------------------------------
    | Maps each Epicor OrderHed.Company code to the display name shown on the
    | slide, in order. ADJUST the codes to match your Epicor companies.
    */
    'companies' => [
        ['code' => 'PUREFLEX', 'name' => 'PureFlex'],
        ['code' => 'NILCOR',   'name' => 'Nil-Cor'],
        ['code' => 'HILLS',    'name' => 'Hills-McCanna'],
        ['code' => 'POLY',     'name' => 'PolyValve'],
        ['code' => 'SAS',      'name' => 'Andronaco SAS'],
    ],

    /*
    |----------------------------------------------------------------------
    | Backlog query (Epicor)
    |----------------------------------------------------------------------
    | Ported from the legacy companyOutput(). ':company' is bound per unit.
    | Returns one row of open-order counts bucketed by ship window.
    */
    'query' => "
        SELECT
          COUNT(OrderHed.OpenOrder) AS open_orders,
          COUNT(CASE WHEN OrderRel.ReqDate <= CONVERT(date, GETDATE()-1) THEN 1 END) AS past_due,
          COUNT(CASE WHEN OrderRel.ReqDate =  CONVERT(date, GETDATE())   THEN 1 END) AS due_today,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE())    AND OrderRel.ReqDate <  CONVERT(date, GETDATE()+8)  THEN 1 END) AS d1_7,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+7)  AND OrderRel.ReqDate <= CONVERT(date, GETDATE()+14) THEN 1 END) AS d8_14,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+14) AND OrderRel.ReqDate <= CONVERT(date, GETDATE()+21) THEN 1 END) AS d15_21,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+21) AND OrderRel.ReqDate <= CONVERT(date, GETDATE()+28) THEN 1 END) AS d22_28,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+28) THEN 1 END) AS d29_plus
        FROM Erp.OrderHed AS OrderHed
        INNER JOIN Erp.OrderDtl AS OrderDtl
          ON OrderHed.Company = OrderDtl.Company
         AND OrderHed.OrderNum = OrderDtl.OrderNum
         AND OrderDtl.KitFlag <> 'C'
        INNER JOIN Erp.OrderRel AS OrderRel
          ON OrderDtl.Company = OrderRel.Company
         AND OrderDtl.OrderNum = OrderRel.OrderNum
         AND OrderDtl.OrderLine = OrderRel.OrderLine
        INNER JOIN Erp.Customer AS Customer
          ON OrderHed.Company = Customer.Company
         AND OrderHed.CustNum = Customer.CustNum
        WHERE OrderHed.OpenOrder = 1
          AND OrderRel.NeedByDate IS NOT NULL
          AND (OrderRel.OurReqQty - OrderRel.OurJobShippedQty - OrderRel.OurStockShippedQty) > 0
          AND OrderHed.Company = :company
    ",
];
