<?php

namespace Database\Seeders;

use App\Models\OtifSnapshot;
use Illuminate\Database\Seeder;

/**
 * Seeds one sample OTIF snapshot so the slide renders before the Epicor
 * connection is wired up. Replaced automatically once `otif:fetch` runs live.
 */
class OtifSeeder extends Seeder
{
    public function run(): void
    {
        OtifSnapshot::where('source', 'sample')->delete();

        $snapshot = OtifSnapshot::create([
            'captured_at' => now(),
            'source' => 'sample',
        ]);

        // [name, open, past_due, due_today, 1-7, 8-14, 15-21, 22-28, 29+]
        $rows = [
            ['PureFlex', 120, 8, 5, 20, 25, 22, 18, 22],
            ['Nil-Cor', 86, 2, 3, 14, 16, 15, 13, 23],
            ['Hills-McCanna', 142, 12, 6, 28, 30, 24, 20, 22],
            ['PolyValve', 64, 0, 2, 11, 12, 10, 9, 20],
            ['Andronaco SAS', 38, 1, 1, 6, 7, 6, 5, 12],
        ];

        foreach ($rows as $i => $r) {
            $snapshot->companies()->create([
                'company_code' => strtoupper(preg_replace('/[^A-Za-z]/', '', $r[0])),
                'company_name' => $r[0],
                'open_orders' => $r[1],
                'past_due' => $r[2],
                'due_today' => $r[3],
                'd1_7' => $r[4],
                'd8_14' => $r[5],
                'd15_21' => $r[6],
                'd22_28' => $r[7],
                'd29_plus' => $r[8],
                'sort_order' => $i,
            ]);
        }
    }
}
