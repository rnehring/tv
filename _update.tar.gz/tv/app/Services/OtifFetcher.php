<?php

namespace App\Services;

use App\Models\OtifSnapshot;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * Pulls the current order backlog from Epicor and writes a new snapshot.
 * Never throws to the caller — on failure it records the error and leaves the
 * previous good snapshot in place so the kiosk keeps showing data.
 */
class OtifFetcher
{
    public function fetch(): OtifSnapshot
    {
        $companies = config('otif.companies', []);
        $query = trim((string) config('otif.query'));

        $snapshot = OtifSnapshot::create([
            'captured_at' => now(),
            'source' => 'epicor',
        ]);

        try {
            $connection = DB::connection('epicor');
            $sort = 0;

            foreach ($companies as $company) {
                $row = $connection->selectOne(str_replace(':company', '?', $query), [$company['code']]);
                $data = (array) ($row ?? []);

                $snapshot->companies()->create([
                    'company_code' => $company['code'],
                    'company_name' => $company['name'],
                    'open_orders' => (int) ($data['open_orders'] ?? 0),
                    'past_due' => (int) ($data['past_due'] ?? 0),
                    'due_today' => (int) ($data['due_today'] ?? 0),
                    'd1_7' => (int) ($data['d1_7'] ?? 0),
                    'd8_14' => (int) ($data['d8_14'] ?? 0),
                    'd15_21' => (int) ($data['d15_21'] ?? 0),
                    'd22_28' => (int) ($data['d22_28'] ?? 0),
                    'd29_plus' => (int) ($data['d29_plus'] ?? 0),
                    'sort_order' => $sort++,
                ]);
            }

            $this->prune();

            return $snapshot->load('companies');
        } catch (Throwable $e) {
            // Mark this attempt failed; latestFresh() will keep serving the prior good one.
            $snapshot->update(['error' => substr($e->getMessage(), 0, 255)]);

            return $snapshot;
        }
    }

    /** Keep only the most recent handful of good snapshots. */
    protected function prune(int $keep = 5): void
    {
        $ids = OtifSnapshot::whereNull('error')
            ->orderByDesc('captured_at')
            ->pluck('id')
            ->slice($keep);

        if ($ids->isNotEmpty()) {
            OtifSnapshot::whereIn('id', $ids)->delete();
        }
    }
}
