@php
    /** @var \App\Models\GasChart $chart */
    $chart = $slide['chart'];
    $tiers = $chart->tiers();
    $top = $chart->topGoal();
    $achieved = (float) $chart->achieved;
    $earned = $chart->earnedLevel();
    $ahead = $chart->isAheadOfPace();
    $paceAmt = $chart->paceAmount();
    $fillColor = $ahead ? '#16a34a' : '#ea580c';

    // Thermometer geometry (0..top mapped onto an 760px band starting at y=60)
    $bandTop = 60; $bandH = 760;
    $yFor = fn ($amt) => $bandTop + $bandH - ($top > 0 ? ($amt / $top) * $bandH : 0);
    $fillY = $yFor($achieved);
    $fillH = ($bandTop + $bandH) - $fillY;
    $paceY = $yFor($paceAmt);
    $lastTier = array_key_last($tiers);
@endphp
<div class="gas">
    @if ($chart->finalized)
        <div class="stamp">Finalized</div>
    @endif
    <div class="head">
        <div>
            <h1>{{ $chart->monthLabel() }} <span>Gift Card Goal</span></h1>
            <div class="sub">Company sales toward the monthly team gift-card levels</div>
        </div>
        <div class="updated">Last updated<br><b>{{ optional($chart->updated_on)->format('M j, Y') ?? '—' }}</b></div>
    </div>

    <div class="body">
        <div class="thermo">
            <div class="bar-wrap">
                <div class="track">
                    <div class="fill" style="height: {{ round($fillH) }}px; background: linear-gradient(180deg, {{ $fillColor }}, {{ $fillColor }}cc);"></div>
                </div>
                <div class="bulb" style="background: {{ $fillColor }};"></div>
                <div class="ticks">
                    @foreach ($tiers as $t => $v)
                        @php $reached = $achieved >= $v; @endphp
                        <div class="tier {{ $reached ? 'reached' : '' }}" style="top: {{ round($yFor($v)) }}px;">
                            <span class="line"></span>
                            <span class="lbl"><b>${{ $t }} card</b> — ${{ number_format($v) }}@if($reached)<span class="chip">REACHED</span>@endif</span>
                        </div>
                    @endforeach
                    <div class="pace" style="top: {{ round($paceY) }}px;">
                        <div class="pl"></div>
                        <div class="pt">Pace: ${{ number_format(round($paceAmt)) }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="stats">
            <div class="earned {{ $earned ? '' : 'none' }}">
                <div class="k">Currently earned</div>
                <div class="v">{{ $earned ? '$'.$earned.' Gift Card' : 'Keep going!' }}</div>
                <div class="n">${{ number_format($achieved) }} in sales · {{ number_format($chart->percentOfTop(), 1) }}% of the ${{ $lastTier }} goal</div>
            </div>
            <div class="grid2">
                <div class="card">
                    <div class="k">Sales to date</div>
                    <div class="v">${{ number_format($achieved) }}</div>
                </div>
                <div class="card">
                    <div class="k">Vs. pace</div>
                    <div class="v" style="font-size:40px;">${{ number_format(round(abs($achieved - $paceAmt))) }}</div>
                    <span class="pace-badge" style="background: {{ $ahead ? '#16a34a' : '#ea580c' }};">{{ $ahead ? 'AHEAD' : 'BEHIND' }}</span>
                </div>
            </div>
            <div class="daily">
                <h3>Daily sales needed</h3>
                <table>
                    @foreach ($tiers as $t => $v)
                        <tr><td>For the ${{ $t }} gift card</td><td>${{ number_format(round($chart->dailyTarget($t))) }}/day</td></tr>
                    @endforeach
                    <tr class="act"><td>Actual daily so far</td><td>${{ number_format(round($chart->dailyActual())) }}/day</td></tr>
                </table>
            </div>
        </div>
    </div>
</div>
