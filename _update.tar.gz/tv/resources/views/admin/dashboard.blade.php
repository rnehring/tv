@extends('layouts.admin')
@section('title', 'Dashboard')

@section('content')
    <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        @php
            $cards = [
                ['label' => 'Active static slides', 'value' => $activeStaticCount.' / '.$staticCount, 'icon' => '🖼️'],
                ['label' => $monthName.' birthdays', 'value' => $birthdaysThisMonth, 'icon' => '🎂'],
                ['label' => $monthName.' anniversaries', 'value' => $anniversariesThisMonth, 'icon' => '🎉'],
                ['label' => 'Display locations', 'value' => $locations->count(), 'icon' => '📍'],
            ];
        @endphp
        @foreach ($cards as $card)
            <div class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-700 dark:bg-gray-800">
                <div class="mb-2 text-2xl">{{ $card['icon'] }}</div>
                <div class="text-3xl font-bold">{{ $card['value'] }}</div>
                <div class="text-sm text-gray-500 dark:text-gray-400">{{ $card['label'] }}</div>
            </div>
        @endforeach
    </div>

    <div class="mt-6 grid gap-5 lg:grid-cols-2">
        <div class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
            <h2 class="mb-3 text-lg font-semibold">Quick actions</h2>
            <div class="flex flex-wrap gap-3">
                <a href="{{ route('admin.slides.create') }}" class="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">+ New static slide</a>
                <a href="{{ route('admin.monthly.index', ['tab' => 'birthdays']) }}" class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 dark:border-gray-600 dark:hover:bg-gray-700">Import birthdays CSV</a>
                <a href="{{ route('admin.monthly.index', ['tab' => 'backgrounds']) }}" class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 dark:border-gray-600 dark:hover:bg-gray-700">Update backgrounds</a>
            </div>
        </div>

        <div class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
            <h2 class="mb-3 text-lg font-semibold">Display links</h2>
            <p class="mb-3 text-sm text-gray-500 dark:text-gray-400">Point each factory TV at one of these URLs.</p>
            <ul class="space-y-2 text-sm">
                <li class="flex items-center justify-between gap-3">
                    <span class="font-medium">All / default</span>
                    <code class="rounded bg-gray-100 px-2 py-1 text-xs dark:bg-gray-700">{{ url('/') }}</code>
                </li>
                @foreach ($locations as $loc)
                    <li class="flex items-center justify-between gap-3">
                        <span class="font-medium">{{ $loc->name }}</span>
                        <code class="rounded bg-gray-100 px-2 py-1 text-xs dark:bg-gray-700">{{ url('/?location='.$loc->slug) }}</code>
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
@endsection
