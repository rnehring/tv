@extends('layouts.admin')
@section('title', 'OTIF backlog')

@section('content')
    @php $isEpicor = $source === 'epicor'; @endphp

    <div class="mb-6 grid gap-5 lg:grid-cols-3">
        {{-- Status --}}
        <div class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-700 dark:bg-gray-800">
            <div class="mb-2 text-sm text-gray-500 dark:text-gray-400">Data source</div>
            <div class="flex items-center gap-2">
                <span class="inline-flex items-center rounded-full px-3 py-1 text-sm font-semibold
                    {{ $isEpicor ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300' }}">
                    {{ $isEpicor ? 'Live · Epicor' : 'Sample data' }}
                </span>
            </div>
            <div class="mt-3 text-sm text-gray-600 dark:text-gray-300">
                @if ($snapshot)
                    Last snapshot: <b>{{ $snapshot->captured_at->diffForHumans() }}</b>
                    ({{ $snapshot->captured_at->format('M j, g:i A') }})
                    @if ($snapshot->isStale())<span class="text-amber-600"> · stale</span>@endif
                @else
                    No snapshot yet.
                @endif
            </div>
            <form method="POST" action="{{ route('admin.otif.refresh') }}" class="mt-4">
                @csrf
                <button type="submit"
                        class="rounded-lg px-4 py-2 text-sm font-medium text-white {{ $isEpicor ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-400 cursor-not-allowed' }}"
                        {{ $isEpicor ? '' : 'disabled title=Enable-epicor-first' }}>
                    Refresh now
                </button>
                @unless ($isEpicor)
                    <p class="mt-2 text-xs text-gray-400">Set <code>OTIF_SOURCE=epicor</code> in <code>.env</code> to enable live pulls.</p>
                @endunless
            </form>
        </div>

        {{-- Business units --}}
        <div class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-700 dark:bg-gray-800 lg:col-span-2">
            <div class="mb-2 text-sm text-gray-500 dark:text-gray-400">Business units (edit in <code>config/otif.php</code>)</div>
            <div class="flex flex-wrap gap-2">
                @foreach ($companies as $c)
                    <span class="rounded-lg border border-gray-200 px-3 py-1.5 text-sm dark:border-gray-600">
                        {{ $c['name'] }} <code class="text-xs text-gray-400">{{ $c['code'] }}</code>
                    </span>
                @endforeach
            </div>
            <p class="mt-3 text-xs text-gray-400">Refreshes automatically every {{ $refreshMinutes }} minutes when live (requires the Laravel scheduler running).</p>
        </div>
    </div>

    {{-- Latest snapshot table --}}
    @if ($snapshot && $snapshot->companies->isNotEmpty())
        <div class="overflow-x-auto rounded-2xl border border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800">
            <table class="w-full text-left text-sm">
                <thead class="bg-gray-50 text-xs uppercase text-gray-500 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th class="px-4 py-3">Business unit</th>
                        <th class="px-4 py-3">On-time</th>
                        <th class="px-4 py-3">Open</th>
                        <th class="px-4 py-3">Past due</th>
                        <th class="px-4 py-3">Today</th>
                        <th class="px-4 py-3">1–7</th>
                        <th class="px-4 py-3">8–14</th>
                        <th class="px-4 py-3">15–21</th>
                        <th class="px-4 py-3">22–28</th>
                        <th class="px-4 py-3">29+</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    @foreach ($snapshot->companies as $c)
                        <tr>
                            <td class="px-4 py-3 font-medium">{{ $c->company_name }}</td>
                            <td class="px-4 py-3">{{ number_format($c->onTimePercent(), 1) }}%</td>
                            <td class="px-4 py-3">{{ $c->open_orders }}</td>
                            <td class="px-4 py-3 text-red-600">{{ $c->past_due }}</td>
                            <td class="px-4 py-3">{{ $c->due_today }}</td>
                            <td class="px-4 py-3">{{ $c->d1_7 }}</td>
                            <td class="px-4 py-3">{{ $c->d8_14 }}</td>
                            <td class="px-4 py-3">{{ $c->d15_21 }}</td>
                            <td class="px-4 py-3">{{ $c->d22_28 }}</td>
                            <td class="px-4 py-3">{{ $c->d29_plus }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif

    {{-- Setup help --}}
    <details class="mt-6 rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-700 dark:bg-gray-800">
        <summary class="cursor-pointer text-sm font-semibold">Wiring up the live Epicor connection</summary>
        <div class="mt-3 space-y-2 text-sm text-gray-600 dark:text-gray-300">
            <p>The app reads Epicor read-only through a dedicated connection. On the host that runs this app (which must be able to reach the Epicor SQL Server and have the <code>sqlsrv</code> or <code>pdo_dblib</code> PHP driver), set these in <code>.env</code>:</p>
            <pre class="overflow-x-auto rounded-lg bg-gray-900 p-4 text-xs text-gray-100">OTIF_SOURCE=epicor
EPICOR_DSN=EpicorMSSQL          # if using a system ODBC DSN
# — or host/port instead of a DSN —
EPICOR_HOST=your-sql-host
EPICOR_PORT=1433
EPICOR_DATABASE=your-epicor-db
EPICOR_USERNAME=readonly_user
EPICOR_PASSWORD=********</pre>
            <p>Confirm the business-unit codes in <code>config/otif.php</code> match your Epicor <code>OrderHed.Company</code> values, then click <b>Refresh now</b>. For automatic updates, run the Laravel scheduler on the host (<code>* * * * * php artisan schedule:run</code>).</p>
        </div>
    </details>
@endsection
