<?php

namespace Database\Seeders;

use App\Models\OtifSnapshot;
use Illuminate\Database\Seeder;

/**
 * Seeds one sample OTIF snapshot (using real figures pulled from Epicor) so the
 * slide renders before the live connection is wired up. Replaced automatically
 * once `otif:fetch` runs against the ERP.
 */
class OtifSeeder extends Seeder
{
    public function run(): void
    {
        OtifSnapshot::where('source', 'sample')->delete();

        $snapshot = OtifSnapshot::create([
            'captured_at' => now(),
            'source' => 'sample',
        ]);

        // [code, name, open, past_due, due_today, 1-7, 8-14, 15-21, 22-28, 29+]
        $rows = [
            ['A65', 'Andronaco', 225, 20, 0, 6, 22, 25, 26, 126],
            ['10', 'Company 10', 203, 155, 0, 0, 0, 0, 0, 0],
            ['20', 'Company 20', 108, 79, 0, 0, 0, 0, 0, 0],
            ['30', 'Company 30', 311, 262, 0, 0, 0, 0, 0, 0],
        ];

        foreach ($rows as $i => $r) {
            $snapshot->companies()->create([
                'company_code' => $r[0],
                'company_name' => $r[1],
                'open_orders' => $r[2],
                'past_due' => $r[3],
                'due_today' => $r[4],
                'd1_7' => $r[5],
                'd8_14' => $r[6],
                'd15_21' => $r[7],
                'd22_28' => $r[8],
                'd29_plus' => $r[9],
                'sort_order' => $i,
            ]);
        }
    }
}
