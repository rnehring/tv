<?php

return [

    /*
    |----------------------------------------------------------------------
    | Data source
    |----------------------------------------------------------------------
    | 'epicor' – pull live from the Epicor SQL Server (see the 'epicor'
    |            connection in config/database.php and the EPICOR_* env vars).
    | 'sample' – keep showing the seeded sample snapshot; never touch the ERP.
    */
    'source' => env('OTIF_SOURCE', 'sample'),

    'max_age_minutes' => env('OTIF_MAX_AGE_MINUTES', 60),
    'refresh_minutes' => env('OTIF_REFRESH_MINUTES', 10),

    /*
    |----------------------------------------------------------------------
    | Business units to display
    |----------------------------------------------------------------------
    | Maps each Epicor OrderHed.Company code to the label shown on the slide,
    | in display order. Only codes listed here are shown; reorder / rename here
    | as needed. (Real codes from the ERP: A65, 10, 20, 30.)
    */
    'companies' => [
        ['code' => 'A65', 'name' => 'Andronaco'],
        ['code' => '10',  'name' => 'Company 10'],
        ['code' => '20',  'name' => 'Company 20'],
        ['code' => '30',  'name' => 'Company 30'],
    ],

    /*
    |----------------------------------------------------------------------
    | Backlog query (Epicor)
    |----------------------------------------------------------------------
    | One grouped query returns every company's open-order counts bucketed by
    | required ship window (ported from the legacy companyOutput / base query).
    | The fetcher matches each returned row to the 'companies' map above.
    */
    'query' => "
        SELECT
          OrderHed.Company AS company_code,
          COUNT(OrderHed.OpenOrder) AS open_orders,
          COUNT(CASE WHEN OrderRel.ReqDate <= CONVERT(date, GETDATE()-1) THEN 1 END) AS past_due,
          COUNT(CASE WHEN OrderRel.ReqDate =  CONVERT(date, GETDATE())   THEN 1 END) AS due_today,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE())    AND OrderRel.ReqDate <  CONVERT(date, GETDATE()+8)  THEN 1 END) AS d1_7,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+7)  AND OrderRel.ReqDate <= CONVERT(date, GETDATE()+14) THEN 1 END) AS d8_14,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+14) AND OrderRel.ReqDate <= CONVERT(date, GETDATE()+21) THEN 1 END) AS d15_21,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+21) AND OrderRel.ReqDate <= CONVERT(date, GETDATE()+28) THEN 1 END) AS d22_28,
          COUNT(CASE WHEN OrderRel.ReqDate >  CONVERT(date, GETDATE()+28) THEN 1 END) AS d29_plus
        FROM Erp.OrderHed AS OrderHed
        INNER JOIN Erp.OrderDtl AS OrderDtl
          ON OrderHed.Company = OrderDtl.Company
         AND OrderHed.OrderNum = OrderDtl.OrderNum
         AND OrderDtl.KitFlag <> 'C'
        INNER JOIN Erp.OrderRel AS OrderRel
          ON OrderDtl.Company = OrderRel.Company
         AND OrderDtl.OrderNum = OrderRel.OrderNum
         AND OrderDtl.OrderLine = OrderRel.OrderLine
        INNER JOIN Erp.Customer AS Customer
          ON OrderHed.Company = Customer.Company
         AND OrderHed.CustNum = Customer.CustNum
        WHERE OrderHed.OpenOrder = 1
          AND OrderRel.NeedByDate IS NOT NULL
          AND (OrderRel.OurReqQty - OrderRel.OurJobShippedQty - OrderRel.OurStockShippedQty) > 0
        GROUP BY OrderHed.Company
    ",
];
