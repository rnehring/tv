@php
    /** @var \App\Models\OtifSnapshot $snapshot */
    $snapshot = $slide['snapshot'];
    $companies = $snapshot->companies;
    $colors = [
        'pastdue' => '#dc2626', 'today' => '#ea580c', 'd1' => '#f59e0b',
        'd2' => '#84cc16', 'd3' => '#22c55e', 'd4' => '#14b8a6', 'd5' => '#3b82f6',
        'nodate' => '#64748b',
    ];
@endphp
<div class="otif">
    <div class="head">
        <div>
            <h1>Order Backlog <span>· On-Time Status</span></h1>
            <div class="sub">Open orders by required ship window, per business unit</div>
        </div>
        <div class="cap">
            As of<br>
            <b>{{ $snapshot->captured_at->format('M j, Y · g:i A') }}</b>
            @if ($snapshot->isStale())<br><span class="stale">⚠ data may be delayed</span>@endif
        </div>
    </div>

    <div class="cards" style="grid-template-columns: repeat({{ max(1, $companies->count()) }}, 1fr);">
        @foreach ($companies as $c)
            @php
                $ot = $c->onTimePercent();
                $otColor = $ot >= 95 ? '#7ef0a6' : ($ot >= 90 ? '#ffd166' : '#fca5a5');
            @endphp
            <div class="card">
                <h2>{{ $c->company_name }}</h2>
                <div class="ot" style="color: {{ $otColor }};">{{ rtrim(rtrim(number_format($ot, 1), '0'), '.') }}<span class="pct">%</span></div>
                <div class="otlabel">on time</div>
                <div class="open">{{ $c->open_orders }} open orders · <span class="pd">{{ $c->past_due }} past due</span></div>
                <div class="stack">
                    @foreach ($c->buckets() as [$label, $count, $key])
                        @if ($count > 0)
                            <span style="flex: {{ $count }}; background: {{ $colors[$key] }};"></span>
                        @endif
                    @endforeach
                </div>
                <div class="legend">
                    @foreach ($c->buckets() as [$label, $count, $key])
                        <div class="li"><span class="sw" style="background: {{ $colors[$key] }};"></span>{{ $label }}<b>{{ $count }}</b></div>
                    @endforeach
                </div>
            </div>
        @endforeach
    </div>

    <div class="foot">Past-due and due-today orders need attention first@if($snapshot->source === 'epicor') · updated automatically from Epicor @endif</div>
</div>
