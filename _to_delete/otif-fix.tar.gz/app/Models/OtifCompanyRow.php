<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OtifCompanyRow extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'otif_snapshot_id', 'company_code', 'company_name',
        'open_orders', 'past_due', 'due_today',
        'd1_7', 'd8_14', 'd15_21', 'd22_28', 'd29_plus', 'sort_order',
    ];

    public function snapshot(): BelongsTo
    {
        return $this->belongsTo(OtifSnapshot::class);
    }

    /** Ship-window buckets in display order: [label, count, css-key]. */
    public function buckets(): array
    {
        $buckets = [
            ['Past due', $this->past_due, 'pastdue'],
            ['Due today', $this->due_today, 'today'],
            ['1–7 days', $this->d1_7, 'd1'],
            ['8–14 days', $this->d8_14, 'd2'],
            ['15–21 days', $this->d15_21, 'd3'],
            ['22–28 days', $this->d22_28, 'd4'],
            ['29+ days', $this->d29_plus, 'd5'],
        ];

        // Open orders with no required ship date aren't in any window — surface
        // the remainder so the bar totals to the open-order count.
        $noDate = $this->open_orders - array_sum(array_column($buckets, 1));
        if ($noDate > 0) {
            $buckets[] = ['No ship date', $noDate, 'nodate'];
        }

        return $buckets;
    }

    /** On-time = open orders that are not already past due. */
    public function onTimePercent(): float
    {
        if ($this->open_orders <= 0) {
            return 100.0;
        }

        return max(0, ($this->open_orders - $this->past_due) / $this->open_orders * 100);
    }
}
